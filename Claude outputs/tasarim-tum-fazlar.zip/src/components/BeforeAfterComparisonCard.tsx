import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { SCORE_LABELS } from "@/services/progress/scoreUtils";
import { BeforeAfterComparison } from "@/services/progress/beforeAfterService";
import { AppColors, radius, spacing } from "@/theme/colors";
import { memoizeStyles } from "@/theme/memoizeStyles";
import { typography } from "@/theme/typography";
import { useThemeColors } from "@/theme/ThemeProvider";
import { Card } from "./Card";

interface BeforeAfterComparisonCardProps {
  comparison: BeforeAfterComparison;
}

export function BeforeAfterComparisonCard({
  comparison
}: BeforeAfterComparisonCardProps): React.JSX.Element {
  const colors = useThemeColors();
  const styles = createStyles(colors);
  const visibleScores = comparison.scoreChanges;

  return (
    <Card style={styles.card}>
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Before / After</Text>
          <Text style={styles.subtitle}>Comparison with your previous answer to the same topic</Text>
        </View>
        <Text style={styles.date}>{formatDate(comparison.beforeRecord.createdAt)}</Text>
      </View>

      <View style={styles.scoreGrid}>
        {visibleScores.map((score) => (
          <View key={score.metric} style={styles.scoreItem}>
            <Text style={styles.scoreLabel}>{SCORE_LABELS[score.metric]}</Text>
            <Text style={[styles.delta, score.delta >= 0 ? styles.positive : styles.negative]}>
              {formatDelta(score.delta)}
            </Text>
            <Text style={styles.scoreMeta}>
              {formatScore(score.before)} {"->"} {formatScore(score.after)}
            </Text>
          </View>
        ))}
      </View>

      <View style={styles.insightGrid}>
        <InsightLine
          label="Error patterns"
          value={`${comparison.beforeErrorPatternCount} -> ${comparison.afterErrorPatternCount}`}
          delta={comparison.errorPatternDelta}
          lowerIsBetter
          styles={styles}
        />
        <InsightLine
          label="Transcript length"
          value={`${comparison.beforeTranscriptWordCount} -> ${comparison.afterTranscriptWordCount} words`}
          delta={comparison.transcriptWordCountDelta}
          styles={styles}
        />
        <InsightLine
          label="Words per minute"
          value={`${formatNumber(comparison.beforeWordsPerMinute)} -> ${formatNumber(
            comparison.afterWordsPerMinute
          )} WPM`}
          delta={comparison.wordsPerMinuteDelta}
          styles={styles}
        />
      </View>
    </Card>
  );
}

function InsightLine({
  label,
  value,
  delta,
  lowerIsBetter = false,
  styles
}: {
  label: string;
  value: string;
  delta: number;
  lowerIsBetter?: boolean;
  styles: ReturnType<typeof createStyles>;
}): React.JSX.Element {
  const isPositive = lowerIsBetter ? delta <= 0 : delta >= 0;

  return (
    <View style={styles.insightLine}>
      <View style={styles.insightCopy}>
        <Text style={styles.scoreLabel}>{label}</Text>
        <Text style={styles.insightValue}>{value}</Text>
      </View>
      <Text style={[styles.delta, isPositive ? styles.positive : styles.negative]}>
        {formatDelta(delta)}
      </Text>
    </View>
  );
}

function formatDelta(value: number): string {
  if (value === 0) {
    return "0";
  }

  return `${value > 0 ? "+" : ""}${formatNumber(value)}`;
}

function formatScore(value: number): string {
  return value.toFixed(0);
}

function formatNumber(value: number): string {
  return Number.isInteger(value) ? value.toFixed(0) : value.toFixed(1);
}

function formatDate(value: string): string {
  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "previous attempt";
  }

  return date.toLocaleDateString("en-US", {
    day: "2-digit",
    month: "short"
  });
}

function buildStyles(colors: AppColors) {
  return StyleSheet.create({
  card: {
    gap: spacing.md
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: spacing.sm
  },
  title: {
    ...typography.h2,
    color: colors.ink
  },
  subtitle: {
    ...typography.caption,
    color: colors.muted,
    marginTop: spacing.xs
  },
  date: {
    ...typography.bodyStrong,
    color: colors.primaryDark,
    fontSize: 13
  },
  scoreGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: spacing.sm
  },
  scoreItem: {
    width: "48%",
    minHeight: 88,
    borderRadius: radius.md,
    backgroundColor: colors.surfaceMuted,
    padding: spacing.sm,
    gap: spacing.xs
  },
  scoreLabel: {
    ...typography.label,
    color: colors.muted
  },
  delta: {
    ...typography.h2,
    fontSize: 18
  },
  positive: {
    color: colors.success
  },
  negative: {
    color: colors.danger
  },
  scoreMeta: {
    ...typography.body,
    color: colors.ink,
    fontSize: 13,
    fontWeight: "700"
  },
  insightGrid: {
    gap: spacing.sm
  },
  insightLine: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    gap: spacing.sm,
    borderTopWidth: 1,
    borderTopColor: colors.line,
    paddingTop: spacing.sm
  },
  insightCopy: {
    flex: 1,
    gap: spacing.xs
  },
  insightValue: {
    ...typography.body,
    color: colors.ink,
    fontWeight: "700"
  }
  });
}

/** Built once per theme rather than on every render — see memoizeStyles. */
const createStyles = memoizeStyles(buildStyles);
