import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { Card } from "./Card";
import { Mistake } from "@/types/models";
import { AppColors, spacing } from "@/theme/colors";
import { memoizeStyles } from "@/theme/memoizeStyles";
import { typography } from "@/theme/typography";
import { useThemeColors } from "@/theme/ThemeProvider";

interface MistakesTableProps {
  mistakes: Mistake[];
}

export function MistakesTable({ mistakes }: MistakesTableProps): React.JSX.Element {
  const colors = useThemeColors();
  const styles = createStyles(colors);

  return (
    <View style={styles.container}>
      {mistakes.map((mistake) => (
        <Card key={mistake.id} style={styles.rowCard}>
          <Text style={styles.label}>Original sentence</Text>
          <Text style={styles.text}>{mistake.originalSentence}</Text>
          <Text style={styles.label}>Problem</Text>
          <Text style={styles.text}>{mistake.problem}</Text>
          <Text style={styles.label}>Correct version</Text>
          <Text style={styles.text}>{mistake.correctVersion}</Text>
          <Text style={styles.label}>Explanation</Text>
          <Text style={styles.text}>{mistake.explanation}</Text>
        </Card>
      ))}
    </View>
  );
}

function buildStyles(colors: AppColors) {
  return StyleSheet.create({
  container: {
    gap: spacing.sm
  },
  rowCard: {
    gap: spacing.xs
  },
  label: {
    ...typography.label,
    color: colors.muted
  },
  text: {
    ...typography.bodyLarge,
    color: colors.ink,
    marginBottom: spacing.xs
  }
  });
}

/** Built once per theme rather than on every render — see memoizeStyles. */
const createStyles = memoizeStyles(buildStyles);
