import React, { useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { AppButton } from "@/components/AppButton";
import { Card } from "@/components/Card";
import { GrammarSpeakingChallenge, GrammarTopic } from "@/data/grammarRoadmap";
import { GrammarLevel } from "@/types/models";
import { AppColors, spacing } from "@/theme/colors";
import { memoizeStyles } from "@/theme/memoizeStyles";
import { typography } from "@/theme/typography";
import { useThemeColors } from "@/theme/ThemeProvider";

interface GrammarTopicCardProps {
  level: GrammarLevel;
  topic: GrammarTopic;
  onStartChallenge: (challenge: GrammarSpeakingChallenge) => void;
}

export function GrammarTopicCard({
  level,
  topic,
  onStartChallenge
}: GrammarTopicCardProps): React.JSX.Element {
  const colors = useThemeColors();
  const styles = createStyles(colors);
  const [isOpen, setIsOpen] = useState(false);
  const miniChallenge: GrammarSpeakingChallenge = {
    id: `${topic.id}-mini`,
    prompt: topic.miniChallenge,
    grammarTopic: topic.title,
    expectedStructures: [topic.title, topic.structure, ...topic.speakingPatterns.slice(0, 2)]
  };

  return (
    <Card style={styles.card}>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={topic.title}
        accessibilityState={{ expanded: isOpen }}
        onPress={() => setIsOpen((current) => !current)}
        style={styles.header}
      >
        <View style={styles.headerCopy}>
          <Text style={styles.level}>{level}</Text>
          <Text style={styles.title}>{topic.title}</Text>
          <Text style={styles.coreFeeling}>{topic.coreFeeling}</Text>
        </View>
        <Text style={styles.toggle}>{isOpen ? "Hide" : "Open"}</Text>
      </Pressable>

      {isOpen ? (
        <View style={styles.details}>
          <InfoBlock colors={colors} label="Structure" value={topic.structure} />
          <ListBlock colors={colors} label="Usage" items={topic.usage} />
          <ListBlock colors={colors} label="Examples" items={topic.examples} />
          <View style={styles.section}>
            <Text style={styles.label}>Common Mistakes</Text>
            {topic.commonMistakes.map((mistake) => (
              <View key={`${mistake.wrong}-${mistake.correct}`} style={styles.mistake}>
                <Text style={styles.wrong}>Wrong: {mistake.wrong}</Text>
                <Text style={styles.correct}>Correct: {mistake.correct}</Text>
              </View>
            ))}
          </View>
          <ListBlock colors={colors} label="Speaking Patterns" items={topic.speakingPatterns} />
          <View style={styles.section}>
            <Text style={styles.label}>Mini Challenge</Text>
            <Text style={styles.body}>{topic.miniChallenge}</Text>
            <AppButton
              label="Start Speaking Practice"
              onPress={() => onStartChallenge(miniChallenge)}
              variant="secondary"
            />
          </View>
        </View>
      ) : null}
    </Card>
  );
}

function InfoBlock({
  colors,
  label,
  value
}: {
  colors: AppColors;
  label: string;
  value: string;
}): React.JSX.Element {
  const styles = createStyles(colors);

  return (
    <View style={styles.section}>
      <Text style={styles.label}>{label}</Text>
      <Text style={styles.body}>{value}</Text>
    </View>
  );
}

function ListBlock({
  colors,
  label,
  items
}: {
  colors: AppColors;
  label: string;
  items: string[];
}): React.JSX.Element {
  const styles = createStyles(colors);

  return (
    <View style={styles.section}>
      <Text style={styles.label}>{label}</Text>
      {items.map((item) => (
        <Text key={item} style={styles.listItem}>
          {item}
        </Text>
      ))}
    </View>
  );
}

function buildStyles(colors: AppColors) {
  return StyleSheet.create({
  card: {
    gap: spacing.sm
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: spacing.sm
  },
  headerCopy: {
    flex: 1,
    gap: spacing.xs
  },
  level: {
    ...typography.label,
    color: colors.primaryDark
  },
  title: {
    ...typography.h1,
    color: colors.ink
  },
  coreFeeling: {
    ...typography.body,
    color: colors.muted
  },
  toggle: {
    ...typography.bodyStrong,
    color: colors.accent
  },
  details: {
    gap: spacing.md,
    borderTopWidth: 1,
    borderTopColor: colors.line,
    paddingTop: spacing.md
  },
  section: {
    gap: spacing.xs
  },
  label: {
    ...typography.label,
    color: colors.muted
  },
  body: {
    ...typography.bodyLarge,
    color: colors.ink
  },
  listItem: {
    ...typography.bodyLarge,
    color: colors.ink
  },
  mistake: {
    gap: spacing.xs
  },
  wrong: {
    ...typography.body,
    color: colors.danger,
    fontWeight: "700"
  },
  correct: {
    ...typography.body,
    color: colors.success,
    fontWeight: "700"
  }
  });
}

/** Built once per theme rather than on every render — see memoizeStyles. */
const createStyles = memoizeStyles(buildStyles);
